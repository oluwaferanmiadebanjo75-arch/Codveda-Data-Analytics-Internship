# Codveda Technology – Data Analytics Internship Projects

Two tasks per level, one file per level (as the submission instructions require).

| Level | Task | File | Dataset |
|---|---|---|---|
| 1 Basic | Task 2: Exploratory Data Analysis | `level1_basic/level1_eda_and_visualization.py` | Diabetes Progression (442 patients) |
| 1 Basic | Task 3: Basic Data Visualization | same file | same |
| 2 Intermediate | Task 1: Regression Analysis | `level2_intermediate/level2_regression_and_clustering.py` | Diabetes Progression |
| 2 Intermediate | Task 3: K-Means Clustering | same file | UCI Wine (178 wines, 13 chemical features) |
| 3 Advanced | Task 1: Predictive Modeling (Classification) | `level3_advanced/level3_classification.py` | Wisconsin Breast Cancer (569 tumours) |
| 3 Advanced | Task 3: NLP Sentiment Analysis | `level3_advanced/level3_nlp_sentiment_analysis.py` | NLTK movie_reviews (2,000 reviews) |

**Run:** `pip install -r requirements.txt`, then `python <file>.py`. Each script saves figures to its own `figures/` folder, CSV tables, and a `*_results.txt` log. The `# %%` markers let you open any script as a notebook in VS Code or paste cells into Colab.

## Key findings

**Level 1 – EDA & Visualization**
- No missing values or duplicates. BMI (r = 0.59) and log-triglycerides (r = 0.57) correlate most with disease progression; HDL is negatively correlated (r = −0.40).
- Total cholesterol and LDL are strongly collinear (r = 0.90), which matters for modelling.
- Mean progression rises sharply with BMI category: Normal 109 → Overweight 165 → Obese 213.

**Level 2 – Regression & Clustering**
- Simple regression (BMI → progression, 80/20 split): slope 10.76 points per BMI unit, test R² = 0.233, RMSE = 63.7. BMI alone is a modest predictor; using all 10 features lifts test R² to 0.453.
- K-Means on standardised wine data: the elbow and the best silhouette score both pick k = 3 (silhouette 0.285). The clusters match the true grape cultivars well (Adjusted Rand Index 0.897), although the labels were never used for fitting.

**Level 3 – Classification**
- Random Forest was best: accuracy 97.4%, precision 100%, recall 92.9%, F1 0.963, AUC 0.995. Logistic Regression was close (F1 0.951, AUC 0.996); Decision Tree trailed (F1 0.895).
- Grid search did not improve test scores for Logistic Regression or Random Forest, and the tuned Decision Tree gained precision but lost recall. With a test set of only 114 rows, these differences are within noise. Recall matters most here because a missed malignant tumour is the costly error.
- Top predictors: worst area, worst concave points, worst radius.

## Limitations
- These are well-known teaching datasets. The sex variable in the diabetes data is coded 1/2 with no documented meaning, so it is shown as "Group 1/2".
- The NLP script was not executed in my build environment. Run it once in Colab and check the output before submitting.
- **Not done:** Level 1 Task 1 (cleaning), Level 2 Task 2 (time series) and Level 3 Task 2 (Power BI/Tableau dashboard). Those need a messy raw CSV, `statsmodels`, or desktop BI software.

---

## LinkedIn checklist (from the instructions)
1. Add the offer letter and completion certificate to your profile (Licenses & Certifications / Experience).
2. Tag **@Codveda** in every post.
3. Use: #CodvedaJourney #CodvedaExperience #FutureWithCodveda #CodvedaAchievements #CodvedaProjects
4. Post a video explanation plus your GitHub repo link.
5. Submit via the Codveda form when it is shared (within the 1-month window).

## Draft LinkedIn post
> 🚀 Internship milestone: Data Analytics at @Codveda Technology, complete!
>
> Over the programme I completed six projects across three levels:
> 📊 **EDA & visualization**: found that BMI category sharply separates diabetes progression (avg. score 109 for normal BMI vs 213 for obese).
> 📈 **Regression**: quantified the BMI effect and showed multi-feature models nearly double explained variance (R² 0.23 → 0.45).
> 🍷 **K-Means clustering**: recovered three wine cultivars from chemistry alone (ARI 0.90).
> 🩺 **Classification**: tuned Logistic Regression, Decision Tree and Random Forest to detect malignant tumours: 97% accuracy, AUC 0.995.
> 💬 **NLP**: sentiment analysis with NLTK and TextBlob.
>
> Tools: Python, pandas, scikit-learn, matplotlib, seaborn, NLTK.
> 🎥 Video walkthrough above | 💻 GitHub: [your repo link]
>
> Thank you @Codveda for the opportunity!
> #CodvedaJourney #CodvedaExperience #FutureWithCodveda #CodvedaAchievements #CodvedaProjects #DataAnalytics #Python #MachineLearning

## Video script (~3 minutes, screen-record the figures)
1. **0:00 – Intro (15s):** Name, domain (Data Analytics), Codveda internship, what you'll show.
2. **0:15 – Level 1 (40s):** Show the correlation heatmap and the BMI bar chart. One sentence on each finding.
3. **1:00 – Level 2 (50s):** Regression fit + residual plot (say R² honestly), then the elbow plot and cluster scatter.
4. **1:50 – Level 3 (50s):** Model-comparison chart, confusion matrices, and why recall matters for cancer detection.
5. **2:40 – Close (20s):** Tools used, GitHub link, thank Codveda, call to connect.
